package Interface1;

import java.io.IOException;

public interface DoText{
    void ShDsh(String file_name1) throws IOException;
}

package Interface1;

import java.io.File;

final public class Stat {
   private int hashcode;
   private char code1;//Просто символ
    int counter;
    public Stat(char code){
        counter = 1;
        this.code1 = code;
        this.hashcode = code;
    }

    public int hashCode(){
        counter++;
        return hashcode;
    }
    public boolean equals(Object obj){
        if(this.hashCode()==obj.hashCode()){
            obj.hashCode();//При вызове всегда добавляется 1, но если равно, добавится два
            return true;
        } else{
            return false;
        }
    }
    char getcode1(){
        return code1;
    }
    int getrealcounter(int all_elements){
        return (counter - all_elements);
    }
}
